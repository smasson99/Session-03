#pragma once
namespace platformer
{
	class Testeur
	{
	public:
		Testeur();
		int testTest();
	};
}

