#include "Testeur.h"

using namespace platformer;

Testeur::Testeur()
{

}

int Testeur::testTest()
{
	return 0;
}

