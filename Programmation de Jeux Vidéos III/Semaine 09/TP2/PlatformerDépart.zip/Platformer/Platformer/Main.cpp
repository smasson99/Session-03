#include <vld.h>
#include "Game.h"

int main()
{
	platformer::Game game;
	return game.run();
}