#include "Game.h"

Game::Game()
{
	//On place dans le contructeur ce qui permet � la game elle-m�me de fonctionner

	mainWin.create(VideoMode(LARGEUR, HAUTEUR, 32), "Circle Beat");  // , Style::Titlebar); / , Style::FullScreen);
	view = mainWin.getDefaultView();

	//Synchonisation coordonn�e � l'�cran!  Normalement 60 frames par secondes. � faire absolument
	mainWin.setVerticalSyncEnabled(true);
	//mainWin.setFramerateLimit(60);  //�quivalent... normalement, mais pas toujours. � utiliser si la synchonisation de l'�cran fonctionne mal.
	//https://www.sfml-dev.org/tutorials/2.0/window-window.php#controlling-the-framerate
}

int Game::run()
{
	if (!init())
	{
		return EXIT_FAILURE;
	}

	while (mainWin.isOpen())
	{
		getInputs();
		update();
		draw();
	}

	return EXIT_SUCCESS;
}

bool Game::init()
{
	//La couleur de fond du cercle est noir
	circle.setRadius(rayon);
	circle.setFillColor(sf::Color(0, 0, 0));

	// d�finit un contour blanc de 1 pixel
	circle.setOutlineThickness(1);
	circle.setOutlineColor(sf::Color(255, 255, 255));

	return true;
}

void Game::getInputs()
{
	//On passe l'�v�nement en r�f�rence et celui-ci est charg� du dernier �v�nement re�u!
	while (mainWin.pollEvent(event))
	{
		//x sur la fen�tre
		if (event.type == Event::Closed)
		{
			mainWin.close();
		}
	}
}

void Game::update()
{
	rayon++;

	if (rayon == 100)
	{
		rayon = 1;
	}

	circle.setRadius(rayon);

	//imaginez votre cercle dans un carr� l'englobant compl�tement
	//Sa position est le point haut/gauche de ce carr�.
	//Le petit calcul ici-bas assure que le centre du cercle soit toujours au centre de l'�cran!
	circle.setPosition(LARGEUR / 2 - rayon, HAUTEUR / 2 - rayon);
}

void Game::draw()
{
	//Toujours important d'effacer l'�cran pr�c�dent
	mainWin.clear();
	mainWin.draw(circle);
	mainWin.display();
}