#pragma once

#include <SFML/Graphics.hpp>
#include "Game.h"

using namespace sf;

class Game
{
public:
	Game();
	int run();

private:
	const int LARGEUR = 800;
	const int HAUTEUR = 600;

	bool init();
	void getInputs();
	void update();
	void draw();

	RenderWindow mainWin;
	View view;
	Event event;

	//Rayon du cercle
	int rayon = 0;
	sf::CircleShape circle;
};