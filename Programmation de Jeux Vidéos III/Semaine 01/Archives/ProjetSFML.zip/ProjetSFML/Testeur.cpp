#include "Testeur.h"


Testeur::Testeur()
{

}

int Testeur::testTest()
{
	return 0;
}

