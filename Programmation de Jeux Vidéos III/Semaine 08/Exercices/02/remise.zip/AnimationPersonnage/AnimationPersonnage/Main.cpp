#include <vld.h>
#include "Game.h"

int main()
{
	isometrique::Game game;
	return game.run();
}