#pragma once

namespace MVC
{
	class Vue
	{
	public:
		Vue();
		void executer();
	};
}