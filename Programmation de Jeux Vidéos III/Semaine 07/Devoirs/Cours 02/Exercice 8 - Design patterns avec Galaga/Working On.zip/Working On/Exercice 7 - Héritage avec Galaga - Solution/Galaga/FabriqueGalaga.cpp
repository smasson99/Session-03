#include "FabriqueGalaga.h"

using namespace galaga;

FabriqueGalaga::FabriqueGalaga(int vitesse, int nbrNiveaux, int nbrAnims, 
    RenderWindow* renderWindow)
{
    int FabriqueGalaga::vitesse(vitesse);
    int nbrNiveaux (nbrNiveaux);
    int nbrAnims(nbrAnims);
    RenderWindow* renderWindow(renderWindow);
    int vitesse(vitesse);
}

void FabriqueGalaga::ChargerData(int vitesse, int nbrNiveaux, int nbrAnims,
    RenderWindow * renderWindow)
{
    FabriqueGalaga(vitesse, nbrNiveaux, nbrAnims, renderWindow);
}

void galaga::FabriqueGalaga::SetPosition(float x, float y)
{
    position = Vector2f(x, y);
}

void galaga::FabriqueGalaga::SetPosition(sf::Vector2f position)
{
    this->position = position;
}

Galaga * FabriqueGalaga::FabriquerGalaga(Galagas type)
{
    if (type == BUTTERFLY)
    {
        Butterfly* res = new Butterfly(position.x, position.y, 1, (int)BUTTERFLY,
            nbrNiveaux, nbrAnims, renderWindow);
        res->ajustementsVisuels();
        return res;
    }
    if (type == CATCHER)
    {
        Catcher* res = new Catcher(position.x, position.y, 1, (int)CATCHER,
            nbrNiveaux, nbrAnims, renderWindow);
        res->ajustementsVisuels();
        return res;
    }
    if (type == WASP)
    {
        Wasp* res = new Wasp(position.x, position.y, 1, (int)WASP,
            nbrNiveaux, nbrAnims, renderWindow);
        res->ajustementsVisuels();
        return res;
    }
    return nullptr;
}
