#include <vld.h>
#include "Game.h"

using namespace galaga;

int main()
{
	Game game;
	return game.run();
}