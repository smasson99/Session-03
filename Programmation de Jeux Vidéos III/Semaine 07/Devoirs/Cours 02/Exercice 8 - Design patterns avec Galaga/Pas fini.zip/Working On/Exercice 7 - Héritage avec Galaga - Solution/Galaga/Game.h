#pragma once

#include <SFML/Graphics.hpp>
#include "Galaga.h"
#include "Spawner.h"
#include <vector>
#include "FabriqueGalaga.h"

using namespace sf;

namespace galaga
{
	class Game
	{
	public:
		Game();
		int run();

	private:
		const int LARGEUR = 1280;
		const int HAUTEUR = 796;
		const int VITESSE = 7;

		//Nombre d'animations et frames par animation qu'on a dans notre spriteSheet.
		const int NOMBRE_ANIMATIONS = 3;
		const int NOMBRE_FRAMES = 2;

		RenderWindow mainWin;
		View view;
		Event event;

		Sprite background;
		Texture backgroundT;

		//Notre tableau de pointeurs de la super-classe
		std::vector<Galaga*> galagas;
        /*Un spawner*/
        Spawner mySpawner;
        bool right = false;
        /*Les fabriques*/
        //FabriqueGalaga fabrique;

		bool init();
		void getInputs();
		void update();
		void draw();
		
		//Nouveau � pr�sent qu'on utilise les pointeurs, on va tout lib�rer avant de terminer
		void unload();
	};
}