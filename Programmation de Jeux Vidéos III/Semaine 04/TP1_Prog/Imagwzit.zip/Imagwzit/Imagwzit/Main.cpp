#include <vld.h>
#include "Game.h"

int main()
{
	Game game;
	return game.run();
}