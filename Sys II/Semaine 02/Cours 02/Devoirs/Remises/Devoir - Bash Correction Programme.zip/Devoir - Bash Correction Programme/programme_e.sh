clear
echo Entrez le nom de l’utilisateur :
read nom
if [ -e "/etc/passwd" ]; then
	grep –w ^$nom /etc/passwd 1>\&2 "/dev/null"
	if test [$?]; then
		echo Le compte de l’utilisateur a été trouvé
		varuid= grep –w ^$nom "/etc/passwd" | cut –d  :  –f3
		vargid= grep –w ^$nom "/etc/passwd" | cut –d  :  –f4
		echo  Son numéro d’identification est $varuid
		echo  Son numéro de groupe est $vargid
		nbre= find "/home/"$nom –u $nom –type f 2 >"/dev/null" | wc –l
			if [ $? == 0 ]; then
				echo Son répertoire personnel contient $nbre fichiers
			else
				echo Son répertoire personnel ne contient aucun fichier
			fi
	else
		echo L’utilisateur $nom n’existe pas 
	fi
else
	echo Le fichier "/etc/passwd" n’est pas accessible
fi
