# utilisation de fonctions
TMP=/tmp
PIDLOG=${TMP}/pidlog$$
DATEFILE==${TMP}/date$$
ERRLOG=${TMP}/demolog
#
# fonction shell pour nettoyer et quitter
errexit()
{
	echo $1
	date >> $ERRLOG
	echo $1 >> $ERRLOG
	rm –f $PIDLOG $DATEFILE
	exit
}
#
# fonction shell pour lire une réponse y/n et fixer code retour 0 ou 1
ok()
{
	while true
	do
		read ans
		case $ans in
			[yY]*) return 0 ;;
			[nN]*) return 1 ;;
			*) echo Please answer y or n ;;
		esac
	done
}
# début traitement de la commande
echo $$ > $PIDLOG
# $$ variable contenant le PID du shell
date > $DATEFILE
#
# test error exit
echo Test errexit function [y/n]?
ok && errexit "Testing the errexit function"
# ^^ pipeline exécuté si vrai (|| utilsé si faux)
echo Normal Termination
echo Please remove $PIDLOG and $DATEFILE
