for fruits in apples pears oranges mangos
do #do exécuté pour chaque élément dans liste
echo $fruits are fruits
done
#Chaque élément dans la liste s'affichera dans la console suivit d'un "are fruits".
