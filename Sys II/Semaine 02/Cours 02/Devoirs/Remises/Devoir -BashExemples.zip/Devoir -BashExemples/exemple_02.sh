until test -r stopfile
	do sleep 2
	echo Hello

done & # & pour exécution en arrière-plan

# Description de ce que ça fait:

# Ce programme continuera d'écrire "Hello" aux
# deux secondes tant que le fichier "stopfile
# ne sera pas crée.
