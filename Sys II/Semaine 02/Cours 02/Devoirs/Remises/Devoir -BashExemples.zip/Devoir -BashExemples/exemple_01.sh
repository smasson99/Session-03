while test -r lockfile ;
do sleep 5 ;
done
