for breed in arabian
 do
	case $breed in
	 # ;; fin des commandes exécutées pour ce cas
	 arabian|palomino|clydesdale) echo $breed is a horse ;;
	 jersey|guernsey|holstein) echo $breed is a cow ;;
	 husky|shepherd|setter|labrador) echo $breed is a dog ;;
	 siamese|persian|angora) echo $breed is a cat ;;
	 *) echo $breed is not in our catalog ;;
	esac
 done

#  Selon ce qui est entré dans le "in", la commande de console va afficher grâce
#  au echo si le string est ou n'est pas dans une des listes.
