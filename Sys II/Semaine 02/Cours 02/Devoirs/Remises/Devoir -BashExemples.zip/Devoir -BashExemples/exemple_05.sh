# liste les sous-répertoires des répertoires donnés en paramètres
# usage : lsdir6 [rép1/ rép2/ ... répn/]
#
if test $# = 0		# $# variable contenant le nombre de paramètres

	then
		param=.
	else
				# $@ variable contenant les paramètres sous 
		param="$@" 	# forme d’une liste, équivalent $1 $2 ... $n
fi
for i in $param
do
    for j in $i/*		#	$i/* la liste des éléments dans le no répertoire
    do
	if test –d $j then	#test permet de créer des éléments conditionnels
		echo $j
	fi 			#fin si
    done			#fin for
done				#fin for
