#include <stdio.h>
int main()
{
	printf("Allo le monde !\n");
	return 0;
}
