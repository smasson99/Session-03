#Samuel Masson. Matricule: 1632010, tous les droits sont réservés.
#Partie #02 ou "B" du TP1, dans le cadre du cours de Système d'Exploitation II 2017, gr:02

#Lancement du programme

#Requirements:
#1- Le programme reçoit un paramètre représentant le nom du fichier à compiler
#2- Le programme gére le cas où le fichier n'existe pas
#3- Le programme copie le fichier résultant "au bon endroit"
#4- Le programme informe l'utilisateur des opérations en cours
#5- Le programme "modifie les permissions" s'il y a lieu
#6- Le programme affiche un message de succès.
#7- Le programme offre la possibilité de lancer le programme si la compilation est un succès

#Vérifier si le nombre de paramètre est valide
if [ ! $# -eq 1 ]
	then
		echo "Veuillez entrer un paramètre après l'appel du programme."
#Si le fichier exste, alors
elif [ -e $1 ]
then
	#Afficher message adresse trouvée
	echo "Programme : $1 trouvé."
	#Informer l'utilisateur que le programme est lancé
	echo "Lancement du programme."
	#S'assurer d'avoir les permissions
	if [ ! -x $1 ]
	then
		#Permissions non-accordées, informer utilisateur
		echo "Permissions non accordées."
		echo "Attribution des permissions au programme"
		#Attribution des droits d'accès
		chmod +x $1
		#S'assurer que l'opération est un succès. Autrement, quitter le programme
		if [ -x $1 ]
		then
			echo "Droits d'accès obtenus."
		else
			echo "Droits non-obtenus"
		fi
	fi
	#Vérifier l'existence du répertoire "bin"
	if [ -d "bin" ]
	then
		#Le fichier existe
		echo "Le répertoire \"bin\" a été trouvé."
	else
		#Le fichier n'existe pas, créer le fichier
		echo "Le répertoire \"bin\" n'a pas été trouvé."
		echo "Création du répertoire."
		mkdir "bin"
		if [ -d "bin" ]
		then
			echo "Création réussie."
		else
			echo "Échec de la création du répertoire."
		fi
	fi
	#Compiler le programme
	gcc -o "bin/$1" $1
	echo "Compilation du programme"
	#S'assurer du résultat et en informer l'utilisateur
	if [ -e "bin/$1" ]
	then
		echo "La compilation est un succès."
		#Offrir l'option d'exécuter le programme à l'utilisateur
		#Demander
		echo "Souhaitez-vous exécuter le programme (O/N) ?"
		#Lire le résultat
		read res
		#Analyser
		case $res in
			#Oui
			O|o|1)echo "Exécution du programme:"
			./"bin/$1" ;;
			#Non, pour tous les autres résultats
			*)echo "Fin du programme." exit ;;
		#Fin analyse
		esac
	else
		echo "Erreur, la compilation a échouée."
	fi
else
	echo "Veuillez entrer un paramètre après l'appel du programme."
fi

echo "Fin du programme."


