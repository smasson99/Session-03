/* version triviale d'utilisation d'un tube */

/*Les includes*/
#include <stdio.h>
#include <stdlib.h>
#include <unistd.h>
/*Déclaration de la fonction main, retourne 0 si tout s'est bien passé et un autre chiffre dans le cas contraire*/
int main()
{
	/*Déclaration du tableau descripteur*/
	int pfd[2], nread;
	/*Création du tableau de caractères pour analyser le nombre d'octets*/
	char s[100];
	/*Création d'un tube à l'aide du tableau pdf, analyser la valeur de retour (autre que 0 signifie une erreur)*/
	if (pipe(pfd) == -1)
	{
		/*Afficher une erreur "write"*/
		perror("Le pipe n'a pas été créé.");
		/*Sortie du programme*/
		exit(1);
	}
	/* [1] signifie que nous sommes en écriture, la commande write, écrira le string "Allo toi !". Il faut aussi entrer en paramètre la longueur de la string*/
	if (write(pfd[1],"Allo toi !",11) == -1)
	{
		/*Afficher une erreur "write"*/
		perror("write");
		/*Sortie du programme*/
		exit(1);
	}
	/* [2] signifie que nous sommes en lecture, la commande read, lit le  */
	switch(nread=read(pfd[0],s,sizeof(s)))
	{
		case -1:
			/*Afficher une erreur "write"*/
			perror("write");
			/*Sortir du programme avec un retour de 1, donc tout ne s'est pas passé comme prévu: il y a eu une erreur.*/
			exit(1);
		case 0:
			/*Dans ce cas-ci, aucun octet n'a été lu, donc afficher "vide"*/
			printf("Vide\n");
			/*Sortie du programme*/
			exit(1);
		default:
			/*Tout s'est bien passé, le nombre d'octets a été lu, afficher celui-ci*/
			printf("%d octets lus dans le tube: %s\n", nread, s);
	}
	/*Tout s'est bien passé, retourner 0*/
	return 0;
}
