/* démo utilisation de pipe */
//Les includes
#include <unistd.h>
#include <stdio.h>
//Déclaration de la méthode main
int main()
{
	/*Initialisation des variables*/
	int tube[2];
	int retexec; 
	int status;
	int ret;
	/*Création du tube(du pipe)*/
	pipe(tube);
	/* vfork est une version allégée de fork...
	Vfork est est une fonction dont le rôle est de créer un enfant et de blocker le parent, jusqu'à la fin de l'exécution de l'enfant.
	*/
	/*Si nous sommes l'enfant, alors*/
	if (vfork() == 0)
	{
		/*Nous sommes l'enfant, l'afficher*/
		printf("enfant\n");
		/*Fermer le tube en écriture (close ferme un descripteur)*/
		close(tube[1]);
		/*Désactiver l'entrée standard (les commandes utilisateur)*/
		close(0);
		/* Accepte l'entrée standard à partir du tube. */
		dup(tube[0]);
		retexec = execl("/bin/sort", "sort", "-r", (char *) 0);
		/* execl("chemin pgm à exécuter", "nom pgm", ["arg 1"], ["arg..."], (char *) 0) */
		printf("erreur exec\n");
		/* si exec fonctionne, le programme enfant se termine ici ! */
		/* si exec ne fonctionne pas, exec retourne -1 dans retexec */
		printf("retour erreur exec %d\n", retexec);
		exit(5);
	}
	/*Nous sommes le parent, l'indiquer*/
	printf("Retour au parent\n");
	/*Fermer le tube en lecture.*/
	close(tube[0]) ;
	/*Ferme la sortie standard.*/
	close(1);
	/*Dirige la sortie standard vers le tube.*/
	dup(tube[1]);
	retexec = execl("/bin/ps", "ps", "-l", (char *) 0);
	printf("retour exec parent = %x\n", retexec);
	/*Tout s'est bien passé, on retourne 0*/	
	return 0;
}
