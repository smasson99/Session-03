/*Les includes*/
#include <stdlib.h>
#include <unistd.h>
#include <stdio.h>

int main()
{
	/*Créer mon pointeur*/
	int p[2];
	/*Créer un entier vide pour l'affichage plus tard*/
	int nread;
	/*Créer un tab de char*/
	char tabChar[100];
	/*Si je ne peux pas créer mon pipe, on arrête tout*/
	if (pipe(p) == -1)
	{
		/*Retourner erreur*/
		perror("Erreur lors de la création de ma pipe.");
		/*Sortir du programme*/
		exit(1);
	}
	/*Je vais écrire dans mon pointeur, je veux aussi m'assurer qu'il n'y ait pas d'erreur*/
	if (write(p[1], "string", sizeof("string")) == -1)
	{
		/*Même chose, j'écris une erreur*/
		perror("Erreur lors de l'écriture dans mon pointeur.");
		/*Je sors du programme*/
		exit(1); /*1 pour dire que ce n'est pas une sortie sans erreur*/
	}
	/*Je vais lire mon pointeur, jeux naturellement m'assurer qu'il n'y ait pas d'erreur*/
	/*Imprimer le contenu du pointeur ainsi que son nombre d'octets.*/
	switch (nread=read(p[0], tabChar, sizeof(tabChar)))
	{
		case 0:
		case 1:
		default:
			printf("%d octets lus dans le tube: %s\n", nread, tabChar);
	}
	/*Tout s'est bien passé, on retourne 0*/
	return 0;
}

