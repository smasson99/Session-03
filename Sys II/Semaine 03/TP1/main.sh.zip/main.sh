#***
#Ce programme fut développé par Samuel Masson 
#(matricule: 1632010) dans le cadre du cours 
#de Système d'Exploitation et Réseau II 2017,
#groupe 02.
#***

#***Début du programme
#!/bin/bash
#Nettoyer la console
clear
#Afficher la version actuelle
version=0.01
#Afficher le texte de base du lancement du programme
echo "Lancement du programme version:$version. Créé par Trilux Inc, tous les droits sont réservés."
echo ""
#Afficher les options d'installation
echo "Bienvenu, voici vos options d'installation:"
echo "1)Institutionnelle || 2)Industrielle || 3)Canceller l'installation"
echo ""
echo "Pour plus d'informations concernant l'organisation des fichiers du répertoire à créer, tappez \"information\" suivis d'un espacement et du numéro de l'option dont vous souhaitez connaître les informations."
echo ""
canStart=false
optionChosen=0
#Tant qu'un option n'est pas choisie, lire ce qui est entré par l'utilisateur
#et agir en fonction des données entrées
while [ $canStart = false ]
	do
		#Lire la commande entrée
		read result
		#Pour chaque cas...
		case $result in
			#Cas #01 : Choisi l'option d'installation 01
			[1]*)
			optionChosen=$result
			canStart=true ;;
			#Cas #02 : Choisi l'option d'installation 02
			[2]*)
			optionChosen=$result
			canStart=true ;;
			#Cas #03 : Demande des informations concernant l'option 01
			["information 1"]*)
			echo "
		INSTITUT 
			PROGRAM 
				SYSTEME 
					PILOTE 
				UTIL 
			DONNEES 
				COURANTE 
					JOURNAL 
				ARCHIVE 
				TEMP 
				" ;;
			#Cas #03 : Demande des informations concernant l'option 02
			["information 2"]*)
			echo "
		INDUSTR 
			PROGRAM 
				SYSTEME 
					PILOTE 
				UTIL 
			DONNEES 
				COURANTE 
					JOURNAL 
				PRODUCTION 
					JOURNAL 
				ARCHIVE 
				TEMP 
				" ;;
			#Cas #04 : Demande de cancellation l'installation
			["fin"]|[3]*) echo "L'installation s'est bel et bien cancellée. Relancez le programme pour recommencer.
" 
			exit;;
			#Cas DEFAULT : La commande entrée est invalide
			*)echo "Choisissez un option valide. (1, 2 ou 3)
" ;;
		esac
	done

#Selon l'option choisie, confirmer d'avoir bien reçu celle-ci
if [ $optionChosen = "1" ]
then
	echo "Information bien reçue: Version Institutionnelle.
"
else
	echo "Information bien reçue: Version Industrielle.
"
fi

#Demander l'adresse du répertoire de base pour procéder à l'installation.
echo "Veuillez entrer l'adresse du répertoire de base pour effectuer l'installation ou tappez \"fin\" pour canceller l'installation et fermer le programme.
"

canContinue=false






