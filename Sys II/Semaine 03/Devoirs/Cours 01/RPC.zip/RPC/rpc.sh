#Déclaration des variables:
rocheRes='roche'
papierRes='papier'
ciseauRes='ciseau'
quitRes='quit'
res=''
iaRes=''
seed=`date | cut -c18-20`
#Lancement du programme, tant que l'utilisateur n'entre pas "quit"
while [res != quit]
	do
		#Nettoyage de l'écran
		#clear
		#Afficher l'entête:
		echo $rocheRes, $papierRes, $ciseauRes "(quit pour terminer)"
		#Lire la saisie
		read $res
		#Écrire le résultat
		echo "Saisie de l'utilisateur:"
		echo $res
		#Maintenant, gérer les cas en fonction du résultat entré:
		#Gestion des cas valides
		if [$res == $rocheRes || $res == $papierRes || $res == $ciseauRes] then
			#Valide, donc jouer le tour de l'ordinateur
			rand=`expr \( \( $seed  \* 5 \)  / 3 \)  % 3`
			#Trouver la valeur choisie par l'ordinateur
			case $rand in
				[0]*) $iaRes=$rocheRes ;;
				[1]*) $iaRes=$papierRes ;;
				[2]*) $iaRes=$ciseauRes ;;
			esac
			#Écrire le résumé des choix
			messageFin=''
			echo "L'utilisateur a choisi " $res ", l'ordinateur a choisi " $iaRes
			#Déterminer qui gagne
			if [$res == $iaRes] then
				$messageFin='Match nul'
			elif [$res == $rocheRes && $iaRes == $papierRes] then
				$messageFin="L'ordinateur a gagné"
			elif [$res == $papierRes && $iaRes == $ciseauRes] then
				$messageFin="L'ordinateur a gagné"
			elif [$res == $ciseauRes && $iaRes == $rocheRes] then
				$messageFin="L'ordinateur a gagné"
			else
				$messageFin="L'utilisateur a gangé"
			fi
			#Afficher le message de fin de partie
			echo $messageFin
		fi
	done
